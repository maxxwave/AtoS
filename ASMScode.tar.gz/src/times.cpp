#include <iostream>
#include <ctime>
#include "../hdr/times.h"
namespace times{
    double time_step=1e-16;
    double loop_time_steps=10000;
    double equilibration_time=100;
    //+many others;
}
