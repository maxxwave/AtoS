#include <iostream>
#include <vector>
#include "../hdr/template.h"
#include "../hdr/storage.h"

namespace st{
             std::vector <template_t::H_internal> H_int;
             std::vector <template_t::H_internal> H_ani;
             std::vector <template_t::H_internal> H_ex;
             std::vector <template_t::H_internal> H_dip;
             std::vector <template_t::H_internal> H_total;
             std::vector <double> H_applied;
          //   std::vector <template_t::H_internal> H_int;
             std::vector <template_t::atom> atom;

}
