#include <iostream>
#include <vector>
#include "../hdr/template.h"
/*
namespace template_t{
    class H_internal{
        public:
            double x;
            double y;
            double z;};
    class atom{
        public:
            double sx;
            double sy;
            double sz;
            double cx;
            double cy;
            double cz;};
}//end of template_t
*/
