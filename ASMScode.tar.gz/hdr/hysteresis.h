#include<iostream>
#ifndef __HYST
#define __HYST
namespace program{
    extern void hysteresis();
    extern int  H_max;
    extern int  H_min;
    extern int DH;
    extern int branch;
    extern int H;

}
#endif
