#include <iostream>
#ifndef __magn
#define __magn
namespace magnetization{
    extern void magnetization_out();
    extern double Mx;
    extern double My;
    extern double Mz;
}
#endif
