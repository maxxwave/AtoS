#include <iostream>
#include <vector>

#ifndef __CREARE
#define __CREARE
namespace create{
	extern int index;
	//boundary parameters
	extern int A;
	extern int B;
	extern int C;
    extern void create_sc();
    extern void create_bcc();
    //so on
}
#endif
