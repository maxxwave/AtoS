#include <iostream>
#include <vector>

#ifndef __TIMES__
#define __TIMES__
namespace times{
    extern double loop_time_steps;
    extern double time_step;
    extern double time_cooling;
    extern double equilibration_time;
    //+many others
}
#endif

